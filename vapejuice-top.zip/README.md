# VapeJuice.top — 全栈骨架(Next.js)

一个最简但完整的前后端骨架：10 个栏目页面 + 2 个后端 API 路由（订阅、产品数据），
方便先上线占位再逐步填充真实内容。

## 技术栈

- **Next.js 14**（App Router）— 在 Hostinger 支持列表里，前端和后端都用同一个框架，部署最省事
- **Tailwind CSS** — 样式
- 纯 JavaScript（无 TypeScript），降低上手成本

## 目录结构

```
app/
  page.js              首页
  layout.js            全局布局（Header/Footer/SEO）
  globals.css          全局样式与视觉token
  site.config.js       导航栏目配置（10个栏目集中管理）
  data/products.js     示例产品数据（先用内存数据，后续换数据库）
  best-disposable/     栏目页 ×10（按你给的10个栏目各一个文件夹）
  ...
  api/
    subscribe/route.js 后端示例1：邮件订阅
    products/route.js  后端示例2：按分类查询产品（GET /api/products?category=xxx）
  sitemap.js           自动生成 sitemap.xml
  robots.js            自动生成 robots.txt
components/
  Header.js / Footer.js / ProductLabelCard.js / RatingGauge.js
```

## ⚠️ 重要：本地先验证一遍

这个项目是在**没有公网访问权限**的沙箱里手写的，没能跑 `npm install` /
`npm run build` 来实际验证。代码经过了人工检查（import 路径、JSX 结构、API 路由签名
都核对过），但**强烈建议你在自己电脑上先跑一遍**，再上传 Hostinger：

```bash
npm install
npm run dev      # 本地预览 http://localhost:3000
npm run build    # 构建生产版本，会暴露任何遗漏的语法/依赖问题
```

如果 `npm run build` 报错，把报错信息发给我（或贴给任何一个 AI 助手），
通常都是一两行小问题，很快能改。

## 部署到 Hostinger（推荐：Node.js Web Apps Hosting）

Hostinger 现在对 Next.js 有专门的 **Node.js 应用托管**，支持完整的 SSR 和 API 路由
（也就是说本项目的后端接口能直接跑），步骤大致是：

1. 把这个项目推送到一个 GitHub 仓库（公开或私有都行）
2. 登录 Hostinger hPanel → **Websites** → **Add Website** → 选 **Node.js Apps**
3. 选择 **Import Git Repository**，授权并选中你的仓库
4. Hostinger 会自动识别这是 Next.js 项目，自动配置构建命令（`npm run build`）和启动命令（`npm run start`）
5. 把域名 `vapejuice.top` 指向这个 Node.js 应用
6. 点 Deploy，等构建完成即可上线

> 也支持直接上传 ZIP 包部署，不一定非要走 GitHub。

### 备选：纯静态导出（如果你只有"共享主机"，没有 Node.js 应用托管）

如果你的 Hostinger 套餐不支持 Node.js 应用（比如最基础的共享主机），可以把站点
导出成纯静态 HTML，但**后端 API 路由（订阅、产品接口）会失效**，因为静态导出没有服务器：

1. 在 `next.config.js` 里加一行：
   ```js
   const nextConfig = {
     output: "export",
     images: { unoptimized: true }
   };
   ```
2. 跑 `npm run build`，生成的静态文件在 `out/` 文件夹
3. 用 Hostinger 文件管理器或 FTP，把 `out/` 里的所有文件上传到 `public_html/`

这种方式简单但只是"纯展示站"，订阅表单等需要后端的功能需要换成第三方服务
（比如表单用 Formspree，邮件订阅用 Mailchimp 的前端 SDK）。

## 接下来可以做的事

- 把 `app/data/products.js` 的示例数据换成真实数据库（Hostinger 自带 MySQL，或用 Supabase/PlanetScale）
- 给每个产品做独立详情页（`app/review/[slug]/page.js`）
- `api/subscribe` 现在只是写进内存数组，重启就丢失，换成真实邮件服务（Resend / Mailchimp API）
- 申请 Google Search Console，提交 `sitemap.xml`（已自动生成，路径是 `/sitemap.xml`）
- 加 Google Analytics / 站内搜索
