import { PRODUCTS } from "@/app/data/products";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get("category");

  const data = category ? PRODUCTS.filter((p) => p.category === category) : PRODUCTS;

  return Response.json({ count: data.length, results: data });
}
