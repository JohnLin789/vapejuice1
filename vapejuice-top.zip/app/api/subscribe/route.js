// 简单的订阅接口示例。
// 当前实现把订阅写入内存数组，仅用于演示前后端联通。
// 上线前请换成真实存储（数据库 / 第三方邮件服务，如 Resend、Mailchimp API）。

const subscribers = globalThis.__vapejuice_subscribers || [];
globalThis.__vapejuice_subscribers = subscribers;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const email = (body?.email || "").trim().toLowerCase();

  if (!email || !EMAIL_RE.test(email)) {
    return Response.json({ error: "Please provide a valid email address" }, { status: 422 });
  }

  if (!subscribers.includes(email)) {
    subscribers.push(email);
  }

  return Response.json({ ok: true, total: subscribers.length }, { status: 201 });
}

export async function GET() {
  // 仅用于本地调试，查看当前已订阅数量；生产环境建议移除或加鉴权。
  return Response.json({ total: subscribers.length });
}
