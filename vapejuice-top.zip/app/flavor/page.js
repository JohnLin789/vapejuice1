import Link from "next/link";

export const metadata = {
  title: "Browse by Flavor",
  description: "Find vape juice, nic salts, and disposables organized by flavor family."
};

const FLAVOR_FAMILIES = [
  { name: "Fruit & Tropical", note: "Watermelon, blue razz, pineapple-coconut blends", count: 3 },
  { name: "Menthol & Ice", note: "Cooling profiles layered under fruit or candy notes", count: 2 },
  { name: "Dessert & Custard", note: "Vanilla, caramel, bakery-style steeped juice", count: 1 },
  { name: "Candy", note: "Skittles-style and nostalgic candy-shop blends", count: 1 },
  { name: "Tobacco & Classic", note: "Coming soon — we're mid-testing this family", count: 0 },
  { name: "Beverage", note: "Coming soon — lemonade, soda, and coffee-inspired juice", count: 0 }
];

export default function FlavorPage() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-14">
      <p className="font-mono text-acid text-xs uppercase tracking-widest2">Taste Index</p>
      <h1 className="font-display text-4xl text-paper mt-3">Browse by Flavor</h1>
      <p className="font-body text-haze mt-3 max-w-2xl leading-relaxed">
        We group flavors by family first, then rank within each family — fruit blends and dessert
        blends are judged on different criteria, so we don't mix the scoring.
      </p>

      <div className="grid md:grid-cols-2 gap-4 mt-10">
        {FLAVOR_FAMILIES.map((f) => (
          <div key={f.name} className="label-card rounded-sm p-5 flex items-start justify-between gap-4">
            <div>
              <h2 className="font-display text-lg text-paper">{f.name}</h2>
              <p className="font-body text-sm text-haze mt-1.5 leading-relaxed">{f.note}</p>
            </div>
            <span className="font-mono text-xs text-acid border border-acid/40 rounded-sm px-2 py-1 shrink-0">
              {f.count} tested
            </span>
          </div>
        ))}
      </div>

      <p className="font-body text-sm text-haze mt-10">
        Looking for a specific bottle?{" "}
        <Link href="/review" className="text-acid hover:underline">
          Browse all reviews
        </Link>{" "}
        instead.
      </p>
    </section>
  );
}
