import { NAV_SECTIONS } from "@/app/site.config";

export default function sitemap() {
  const base = "https://vapejuice.top";
  const now = new Date();

  const routes = ["", ...NAV_SECTIONS.map((s) => s.href)];

  return routes.map((href) => ({
    url: `${base}${href}`,
    lastModified: now,
    changeFrequency: "weekly",
    priority: href === "" ? 1 : 0.7
  }));
}
