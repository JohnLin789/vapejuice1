const RELEASES = [
  { date: "2026-06", name: "Geek Bar Pulse X", note: "First disposable we've tested with a battery + e-liquid level screen that's actually accurate." },
  { date: "2026-05", name: "Lost Mary OS5000", note: "Refreshed mesh coil from the OS4000 — testing now to see if flavor stability improved." },
  { date: "2026-04", name: "Naked 100 Nic Salt — Lava Flow", note: "New tropical line extension; full review published." },
  { date: "2026-03", name: "VaporVape Saltz — Rainbow Drop", note: "Brand's first nic salt SKU; added to our Brands directory." }
];

export const metadata = {
  title: "New Releases",
  description: "Newest disposables, nic salts, and vape juice we've added to the testing queue or finished reviewing."
};

export default function NewReleasesPage() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-14">
      <p className="font-mono text-acid text-xs uppercase tracking-widest2">Timeline</p>
      <h1 className="font-display text-4xl text-paper mt-3">New Releases</h1>
      <p className="font-body text-haze mt-3 max-w-2xl leading-relaxed">
        What's new to the market and where it stands in our testing queue.
      </p>

      <div className="mt-10 relative pl-6 border-l border-paper/15">
        {RELEASES.map((r) => (
          <div key={r.name + r.date} className="mb-8 relative">
            <span className="absolute -left-[29px] top-1 w-3 h-3 rounded-full bg-acid" />
            <p className="font-mono text-xs text-acid uppercase tracking-widest2">{r.date}</p>
            <h2 className="font-display text-lg text-paper mt-1">{r.name}</h2>
            <p className="font-body text-sm text-haze mt-1 leading-relaxed max-w-xl">{r.note}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
