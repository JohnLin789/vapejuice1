// 演示用的产品数据。
// 上线后建议替换为真实数据库（如 Hostinger 的 MySQL，或 PlanetScale / Supabase 等）。

export const PRODUCTS = [
  {
    id: "geek-bar-pulse-x",
    name: "Geek Bar Pulse X",
    category: "best-disposable",
    flavor: "Watermelon Ice",
    nicotineMg: 50,
    puffs: 25000,
    rating: 4.6,
    summary:
      "Dual-mesh coil keeps flavor consistent from puff 1 to puff 25,000 — the most even-burning disposable we've tested this cycle.",
    pros: ["Screen shows battery + juice level", "Very stable flavor curve", "USB-C rechargeable"],
    cons: ["Pricier than single-mesh disposables", "Watermelon fades slightly after 60%"]
  },
  {
    id: "lost-mary-os5000",
    name: "Lost Mary OS5000",
    category: "best-disposable",
    flavor: "Blue Razz Lemonade",
    nicotineMg: 50,
    puffs: 5000,
    rating: 4.3,
    summary:
      "A tighter draw and brighter citrus-forward profile than most razz blends, with no noticeable burnt-coil taste near empty.",
    pros: ["Compact, pocket-friendly", "Bright, true-to-fruit flavor"],
    cons: ["Lower puff count than flagship models"]
  },
  {
    id: "naked100-nic-salt-lava-flow",
    name: "Naked 100 Nic Salt — Lava Flow",
    category: "best-nic-salt",
    flavor: "Strawberry, Pineapple, Coconut",
    nicotineMg: 35,
    bottleMl: 30,
    rating: 4.5,
    summary:
      "A tropical blend that leans coconut-forward rather than candy-sweet, built for all-day MTL pod use.",
    pros: ["Balanced sweetness, not cloying", "Smooth 35mg throat hit"],
    cons: ["Coconut note dominates if you steep it long"]
  },
  {
    id: "vapor-vape-saltz-rainbow",
    name: "VaporVape Saltz — Rainbow Drop",
    category: "best-nic-salt",
    flavor: "Skittles-style Candy",
    nicotineMg: 50,
    bottleMl: 30,
    rating: 4.2,
    summary:
      "Nostalgic candy profile that holds up well in mesh pods without turning into a single muddy sweetness.",
    pros: ["Distinct fruit notes stay separate", "Good coil life, low gunking"],
    cons: ["Very sweet — not for menthol/tobacco purists"]
  },
  {
    id: "juice-head-freeze-peach-pear",
    name: "Juice Head Freeze — Peach Pear",
    category: "best-vape-juice",
    flavor: "Peach, Pear, Menthol",
    nicotineMg: 0,
    bottleMl: 100,
    vgPg: "70/30",
    rating: 4.4,
    summary:
      "A freebase 100ml short-fill where the menthol is cooling rather than icy-numb, letting the peach-pear stay forward.",
    pros: ["Great for sub-ohm clouds", "Menthol doesn't overpower fruit"],
    cons: ["High VG can run thicker in low-wattage pens"]
  },
  {
    id: "five-pawns-castle-long",
    name: "Five Pawns — Castle Long Reserve",
    category: "best-vape-juice",
    flavor: "Vanilla Custard, Caramel",
    nicotineMg: 0,
    bottleMl: 60,
    vgPg: "70/30",
    rating: 4.7,
    summary:
      "Dessert-style custard that reads more 'baked' than 'syrupy' — one of the more restrained vanilla blends on the market.",
    pros: ["Layered, not one-note sweet", "Ages well with 1-2 week steep"],
    cons: ["Custard juices will gunk coils faster than fruit"]
  }
];

export function getProductsByCategory(category) {
  return PRODUCTS.filter((p) => p.category === category);
}
