export const NAV_SECTIONS = [
  { label: "Best Disposable", href: "/best-disposable" },
  { label: "Best Nic Salt", href: "/best-nic-salt" },
  { label: "Best Vape Juice", href: "/best-vape-juice" },
  { label: "Review", href: "/review" },
  { label: "Compare", href: "/compare" },
  { label: "Flavor", href: "/flavor" },
  { label: "Guide", href: "/guide" },
  { label: "Brands", href: "/brands" },
  { label: "FAQ", href: "/faq" },
  { label: "New Releases", href: "/new-releases" }
];

export const SITE = {
  name: "VapeJuice.top",
  tagline: "The world's vape encyclopedia",
  description:
    "Independent reviews, lab-style comparisons, and flavor breakdowns for disposables, nic salts, and vape juice — built for adult vapers and former smokers researching a switch."
};
