import { PRODUCTS } from "@/app/data/products";
import RatingGauge from "@/components/RatingGauge";

export const metadata = {
  title: "Compare Products",
  description: "Side-by-side spec comparison for disposables, nic salts, and vape juice."
};

export default function ComparePage() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-14">
      <p className="font-mono text-acid text-xs uppercase tracking-widest2">Side-by-side</p>
      <h1 className="font-display text-4xl text-paper mt-3">Compare</h1>
      <p className="font-body text-haze mt-3 max-w-2xl leading-relaxed">
        Every spec we measure, lined up in one table. Sort by category to compare like with like.
      </p>

      <div className="mt-10 overflow-x-auto border border-paper/10 rounded-sm">
        <table className="w-full text-sm font-body min-w-[720px]">
          <thead>
            <tr className="bg-panel text-haze font-display text-[11px] uppercase tracking-wide text-left">
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Flavor</th>
              <th className="px-4 py-3">Nicotine</th>
              <th className="px-4 py-3">Rating</th>
            </tr>
          </thead>
          <tbody>
            {PRODUCTS.map((p, i) => (
              <tr
                key={p.id}
                className={i % 2 === 0 ? "bg-ink" : "bg-panel/40"}
              >
                <td className="px-4 py-3 text-paper font-medium">{p.name}</td>
                <td className="px-4 py-3 text-haze capitalize">{p.category.replace(/-/g, " ")}</td>
                <td className="px-4 py-3 text-haze">{p.flavor}</td>
                <td className="px-4 py-3 font-mono text-acid">
                  {p.nicotineMg != null ? `${p.nicotineMg}mg` : "—"}
                </td>
                <td className="px-4 py-3 w-40">
                  <RatingGauge rating={p.rating} size="compact" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
