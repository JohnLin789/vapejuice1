import { getProductsByCategory } from "@/app/data/products";
import ProductLabelCard from "@/components/ProductLabelCard";

export const metadata = {
  title: "Best Nic Salt E-Liquids",
  description: "Top-rated nic salt e-liquids for pod systems, ranked on throat hit, flavor balance, and coil life."
};

export default function BestNicSaltPage() {
  const products = getProductsByCategory("best-nic-salt");

  return (
    <section className="mx-auto max-w-6xl px-5 py-14">
      <p className="font-mono text-acid text-xs uppercase tracking-widest2">Category 02</p>
      <h1 className="font-display text-4xl text-paper mt-3">Best Nic Salt E-Liquids</h1>
      <p className="font-body text-haze mt-3 max-w-2xl leading-relaxed">
        Built for MTL pod systems. We score throat hit smoothness alongside flavor, since a harsh
        35mg salt can ruin an otherwise great blend.
      </p>

      <div className="grid md:grid-cols-2 gap-5 mt-10">
        {products.map((p) => (
          <ProductLabelCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}
