import { getProductsByCategory } from "@/app/data/products";
import ProductLabelCard from "@/components/ProductLabelCard";

export const metadata = {
  title: "Best Disposable Vapes",
  description: "Tested and ranked disposable vapes — puff count, flavor stability, and build quality compared."
};

export default function BestDisposablePage() {
  const products = getProductsByCategory("best-disposable");

  return (
    <section className="mx-auto max-w-6xl px-5 py-14">
      <p className="font-mono text-acid text-xs uppercase tracking-widest2">Category 01</p>
      <h1 className="font-display text-4xl text-paper mt-3">Best Disposable Vapes</h1>
      <p className="font-body text-haze mt-3 max-w-2xl leading-relaxed">
        Ranked by flavor consistency across the full puff count, not just the first few draws —
        that's where most disposables fall apart.
      </p>

      <div className="grid md:grid-cols-2 gap-5 mt-10">
        {products.map((p) => (
          <ProductLabelCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}
