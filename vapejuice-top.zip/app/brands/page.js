const BRANDS = [
  { name: "Geek Bar", focus: "Disposables", founded: "2021", tested: 4 },
  { name: "Lost Mary", focus: "Disposables", founded: "2022", tested: 3 },
  { name: "Naked 100", focus: "Nic Salt & Freebase", founded: "2016", tested: 5 },
  { name: "Juice Head", focus: "Vape Juice", founded: "2017", tested: 2 },
  { name: "Five Pawns", focus: "Premium Vape Juice", founded: "2013", tested: 2 },
  { name: "VaporVape", focus: "Nic Salt", founded: "2019", tested: 1 }
];

export const metadata = {
  title: "Brands",
  description: "Vape and e-liquid brands covered on VapeJuice.top, with how many products we've independently tested from each."
};

export default function BrandsPage() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-14">
      <p className="font-mono text-acid text-xs uppercase tracking-widest2">Directory</p>
      <h1 className="font-display text-4xl text-paper mt-3">Brands</h1>
      <p className="font-body text-haze mt-3 max-w-2xl leading-relaxed">
        We disclose how many SKUs from each brand we've actually tested ourselves, so you can tell
        a thin profile from a thoroughly reviewed one.
      </p>

      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4 mt-10">
        {BRANDS.map((b) => (
          <div key={b.name} className="label-card rounded-sm p-5">
            <h2 className="font-display text-lg text-paper">{b.name}</h2>
            <p className="font-body text-sm text-haze mt-1">{b.focus}</p>
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-paper/10 font-mono text-[11px] text-haze">
              <span>Est. {b.founded}</span>
              <span className="text-acid">{b.tested} tested</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
