import Link from "next/link";
import { NAV_SECTIONS } from "@/app/site.config";
import { PRODUCTS } from "@/app/data/products";
import ProductLabelCard from "@/components/ProductLabelCard";

export default function HomePage() {
  const featured = PRODUCTS.slice(0, 3);

  return (
    <>
      {/* HERO */}
      <section className="border-b border-paper/10">
        <div className="mx-auto max-w-6xl px-5 pt-16 pb-14">
          <p className="font-mono text-acid text-xs uppercase tracking-widest2">
            Vol. 01 — Independent Vape Reference
          </p>
          <h1 className="font-display text-4xl sm:text-5xl md:text-6xl text-paper mt-4 max-w-3xl leading-[1.05]">
            Every flavor, every coil, every claim —{" "}
            <span className="text-acid">measured before it's recommended.</span>
          </h1>
          <p className="font-body text-haze text-base md:text-lg mt-5 max-w-2xl leading-relaxed">
            VapeJuice.top tests disposables, nic salts, and bottled juice the same way each time,
            then publishes the numbers next to the verdict. No sponsored rankings, no guesswork.
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/best-disposable"
              className="bg-acid text-ink font-display text-xs uppercase tracking-wide px-5 py-3 rounded-sm hover:bg-paper transition-colors focus-ring"
            >
              See Best Disposables
            </Link>
            <Link
              href="/guide"
              className="border border-paper/25 text-paper font-display text-xs uppercase tracking-wide px-5 py-3 rounded-sm hover:border-acid hover:text-acid transition-colors focus-ring"
            >
              New to vaping? Start here
            </Link>
          </div>
        </div>
        <div className="gauge-line-major" />
      </section>

      {/* SECTION GRID — 10个栏目导览 */}
      <section className="mx-auto max-w-6xl px-5 py-16">
        <div className="flex items-baseline justify-between mb-7">
          <h2 className="font-display text-2xl text-paper uppercase tracking-wide">Browse the encyclopedia</h2>
          <span className="font-mono text-xs text-haze">{NAV_SECTIONS.length} sections</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {NAV_SECTIONS.map((item, i) => (
            <Link
              key={item.href}
              href={item.href}
              className="label-card rounded-sm p-4 flex flex-col justify-between h-28 hover:translate-y-[-2px] transition-transform focus-ring"
            >
              <span className="font-mono text-acid text-[11px]">{String(i + 1).padStart(2, "0")}</span>
              <span className="font-display text-sm text-paper uppercase leading-tight">{item.label}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* FEATURED REVIEWS */}
      <section className="mx-auto max-w-6xl px-5 py-16 border-t border-paper/10">
        <div className="flex items-baseline justify-between mb-7">
          <h2 className="font-display text-2xl text-paper uppercase tracking-wide">Latest verdicts</h2>
          <Link href="/review" className="font-mono text-xs text-acid hover:underline">
            All reviews →
          </Link>
        </div>

        <div className="grid md:grid-cols-3 gap-5">
          {featured.map((product) => (
            <ProductLabelCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* DISCLAIMER STRIP */}
      <section className="border-t border-paper/10 bg-panel/50">
        <div className="mx-auto max-w-6xl px-5 py-10 font-body text-sm text-haze leading-relaxed">
          VapeJuice.top is an independent editorial resource for adults 21 and older who already
          use or are researching nicotine vapor products. We do not sell products directly and we
          do not market vaping as risk-free or as a smoking-cessation device. If you don't
          currently use nicotine, we don't recommend starting.
        </div>
      </section>
    </>
  );
}
