import { PRODUCTS } from "@/app/data/products";
import ProductLabelCard from "@/components/ProductLabelCard";

export const metadata = {
  title: "All Reviews",
  description: "Every product VapeJuice.top has tested, with full scoring breakdowns."
};

export default function ReviewPage() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-14">
      <p className="font-mono text-acid text-xs uppercase tracking-widest2">Archive</p>
      <h1 className="font-display text-4xl text-paper mt-3">All Reviews</h1>
      <p className="font-body text-haze mt-3 max-w-2xl leading-relaxed">
        Every test we've published, in one place. Each verdict is re-checked after 90 days to make
        sure formulations haven't quietly changed.
      </p>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5 mt-10">
        {PRODUCTS.map((p) => (
          <ProductLabelCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}
