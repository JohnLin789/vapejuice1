const FAQS = [
  {
    q: "Is VapeJuice.top selling anything?",
    a: "No. We're an independent editorial site. We don't sell e-liquid, hardware, or run an online store — our content is reviews, comparisons, and guides."
  },
  {
    q: "Who is this site for?",
    a: "Adult vapers (21+) and former smokers who already use nicotine and want product research before buying. It is not intended for people who don't currently use nicotine."
  },
  {
    q: "How do you score products?",
    a: "Each product is tested across flavor consistency, throat hit (for nic salts), build quality, and value, using the same rubric every time. See the Guide section for the full breakdown."
  },
  {
    q: "Do brands pay for placement or higher ratings?",
    a: "No. Ratings are not for sale. If we ever accept free samples for testing, the review discloses that explicitly."
  },
  {
    q: "Is vaping safer than smoking?",
    a: "We don't make medical claims either way. If you have health questions about nicotine or vaping, talk to a doctor or a licensed smoking-cessation service rather than relying on a product review site."
  }
];

export const metadata = {
  title: "FAQ",
  description: "Common questions about VapeJuice.top's reviews, scoring method, and editorial policy."
};

export default function FaqPage() {
  return (
    <section className="mx-auto max-w-3xl px-5 py-14">
      <p className="font-mono text-acid text-xs uppercase tracking-widest2">Editorial Policy</p>
      <h1 className="font-display text-4xl text-paper mt-3">FAQ</h1>

      <div className="mt-10 divide-y divide-paper/10 border-t border-b border-paper/10">
        {FAQS.map((item) => (
          <details key={item.q} className="group py-5">
            <summary className="font-display text-paper cursor-pointer list-none flex items-center justify-between gap-4 focus-ring rounded-sm">
              {item.q}
              <span className="font-mono text-acid text-sm group-open:rotate-45 transition-transform shrink-0">+</span>
            </summary>
            <p className="font-body text-sm text-haze mt-3 leading-relaxed">{item.a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
