const GUIDES = [
  {
    title: "Nic Salt vs. Freebase: What Actually Changes",
    level: "Beginner",
    summary:
      "The chemistry behind why nic salts feel smoother at higher mg, and when freebase still makes more sense."
  },
  {
    title: "Reading a Disposable's Spec Sheet",
    level: "Beginner",
    summary:
      "Puff count, mesh vs. single coil, and why two 'same size' disposables can taste completely different."
  },
  {
    title: "How We Score Throat Hit",
    level: "Method",
    summary: "A walkthrough of our internal rubric, so our ratings are reproducible, not vibes-based."
  },
  {
    title: "VG/PG Ratios for Sub-Ohm vs. Pod Systems",
    level: "Intermediate",
    summary: "Why a 70/30 short-fill can flood a pod coil but feel perfect in a sub-ohm tank."
  },
  {
    title: "Steeping Vape Juice: Does It Actually Matter",
    level: "Intermediate",
    summary: "Which flavor families benefit from a 1-2 week steep, and which ones just go stale."
  }
];

export const metadata = {
  title: "Guides",
  description: "Plain-language guides to vaping terminology, hardware, and how VapeJuice.top scores products."
};

export default function GuidePage() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-14">
      <p className="font-mono text-acid text-xs uppercase tracking-widest2">Reference</p>
      <h1 className="font-display text-4xl text-paper mt-3">Guides</h1>
      <p className="font-body text-haze mt-3 max-w-2xl leading-relaxed">
        No jargon left unexplained. Start with the beginner guides if any of our spec sheets read
        like another language.
      </p>

      <div className="mt-10 divide-y divide-paper/10 border-t border-b border-paper/10">
        {GUIDES.map((g) => (
          <article key={g.title} className="py-6 flex flex-col md:flex-row md:items-baseline gap-2 md:gap-6">
            <span className="font-mono text-[11px] uppercase tracking-widest2 text-acid w-28 shrink-0">
              {g.level}
            </span>
            <div>
              <h2 className="font-display text-lg text-paper">{g.title}</h2>
              <p className="font-body text-sm text-haze mt-1 leading-relaxed max-w-2xl">{g.summary}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
