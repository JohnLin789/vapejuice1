import Link from "next/link";

export default function NotFound() {
  return (
    <section className="mx-auto max-w-2xl px-5 py-24 text-center">
      <p className="font-mono text-acid text-xs uppercase tracking-widest2">Error 404</p>
      <h1 className="font-display text-4xl text-paper mt-3">Empty bottle.</h1>
      <p className="font-body text-haze mt-3 leading-relaxed">
        Nothing's stocked at this address. The page may have been renamed or never existed.
      </p>
      <Link
        href="/"
        className="inline-block mt-6 bg-acid text-ink font-display text-xs uppercase tracking-wide px-5 py-3 rounded-sm hover:bg-paper transition-colors focus-ring"
      >
        Back to homepage
      </Link>
    </section>
  );
}
