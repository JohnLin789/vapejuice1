import { getProductsByCategory } from "@/app/data/products";
import ProductLabelCard from "@/components/ProductLabelCard";

export const metadata = {
  title: "Best Vape Juice (Freebase & Short-Fills)",
  description: "Top freebase vape juice and short-fills for sub-ohm setups, ranked on flavor depth and cloud production."
};

export default function BestVapeJuicePage() {
  const products = getProductsByCategory("best-vape-juice");

  return (
    <section className="mx-auto max-w-6xl px-5 py-14">
      <p className="font-mono text-acid text-xs uppercase tracking-widest2">Category 03</p>
      <h1 className="font-display text-4xl text-paper mt-3">Best Vape Juice</h1>
      <p className="font-body text-haze mt-3 max-w-2xl leading-relaxed">
        Freebase and short-fill bottles for sub-ohm tanks, ranked on flavor depth, VG/PG balance,
        and how well each blend holds up over a steep.
      </p>

      <div className="grid md:grid-cols-2 gap-5 mt-10">
        {products.map((p) => (
          <ProductLabelCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}
