// 评分刻度尺：把 0-5 分映射成一条带刻度的进度条，呼应"实验室量表"的视觉概念。
export default function RatingGauge({ rating, size = "default" }) {
  const pct = Math.max(0, Math.min(5, rating)) / 5 * 100;
  const isCompact = size === "compact";

  return (
    <div className="flex items-center gap-2.5">
      <div
        className={`relative flex-1 ${isCompact ? "h-1.5" : "h-2"} bg-paper/10 rounded-full overflow-hidden`}
        role="img"
        aria-label={`Rating ${rating} out of 5`}
      >
        <div
          className="absolute inset-y-0 left-0 bg-acid rounded-full"
          style={{ width: `${pct}%` }}
        />
        {[20, 40, 60, 80].map((mark) => (
          <span
            key={mark}
            className="absolute inset-y-0 w-px bg-ink/40"
            style={{ left: `${mark}%` }}
          />
        ))}
      </div>
      <span className="font-mono text-acid text-sm shrink-0">{rating.toFixed(1)}</span>
    </div>
  );
}
