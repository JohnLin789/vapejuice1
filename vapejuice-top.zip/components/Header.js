"use client";

import Link from "next/link";
import { useState } from "react";
import { NAV_SECTIONS, SITE } from "@/app/site.config";

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-paper/10 bg-ink/95 backdrop-blur">
      <div className="bg-acid text-ink text-center text-[11px] font-mono tracking-widest2 uppercase py-1.5 px-4">
        21+ only · Nicotine is an addictive chemical · Independent editorial, not a retailer
      </div>

      <div className="mx-auto max-w-6xl px-5 flex items-center justify-between h-16">
        <Link href="/" className="flex items-baseline gap-2 focus-ring rounded-sm">
          <span className="font-display text-xl tracking-wide text-paper">
            VAPEJUICE<span className="text-acid">.</span>TOP
          </span>
        </Link>

        <nav className="hidden lg:flex items-center gap-1 font-display text-[12.5px] uppercase tracking-wide">
          {NAV_SECTIONS.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="px-3 py-2 text-haze hover:text-acid transition-colors focus-ring rounded-sm"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <button
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className="lg:hidden text-paper font-mono text-xs border border-paper/20 rounded-sm px-3 py-2 focus-ring"
        >
          {open ? "CLOSE" : "MENU"}
        </button>
      </div>

      {open && (
        <nav className="lg:hidden border-t border-paper/10 px-5 py-3 grid grid-cols-2 gap-1 font-display text-sm uppercase">
          {NAV_SECTIONS.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="py-2 text-haze hover:text-acid transition-colors"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
