"use client";

import Link from "next/link";
import { useState } from "react";
import { NAV_SECTIONS, SITE } from "@/app/site.config";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("idle"); // idle | loading | done | error

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email })
      });
      if (!res.ok) throw new Error("failed");
      setStatus("done");
      setEmail("");
    } catch {
      setStatus("error");
    }
  }

  return (
    <footer className="border-t border-paper/10 mt-24">
      <div className="mx-auto max-w-6xl px-5 py-14 grid gap-10 md:grid-cols-[1.2fr_1fr_1fr]">
        <div>
          <p className="font-display text-lg text-paper">
            VAPEJUICE<span className="text-acid">.</span>TOP
          </p>
          <p className="mt-3 text-sm text-haze font-body leading-relaxed max-w-sm">
            {SITE.description}
          </p>

          <form onSubmit={handleSubmit} className="mt-5 flex max-w-sm gap-2">
            <label htmlFor="footer-email" className="sr-only">
              Email address
            </label>
            <input
              id="footer-email"
              type="email"
              required
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1 bg-panel border border-paper/15 rounded-sm px-3 py-2 text-sm text-paper placeholder:text-haze/60 focus-ring"
            />
            <button
              type="submit"
              disabled={status === "loading"}
              className="bg-acid text-ink font-display text-xs uppercase tracking-wide px-4 py-2 rounded-sm hover:bg-paper transition-colors disabled:opacity-60 focus-ring"
            >
              {status === "loading" ? "..." : "Notify me"}
            </button>
          </form>
          {status === "done" && (
            <p className="mt-2 text-xs text-acid font-mono">Subscribed. Welcome aboard.</p>
          )}
          {status === "error" && (
            <p className="mt-2 text-xs text-ember font-mono">Something went wrong — try again.</p>
          )}
        </div>

        <div>
          <p className="font-display text-xs uppercase tracking-widest2 text-haze mb-3">Sections</p>
          <ul className="space-y-1.5 text-sm font-body">
            {NAV_SECTIONS.slice(0, 5).map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="text-paper/80 hover:text-acid transition-colors">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <p className="font-display text-xs uppercase tracking-widest2 text-haze mb-3">More</p>
          <ul className="space-y-1.5 text-sm font-body">
            {NAV_SECTIONS.slice(5).map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="text-paper/80 hover:text-acid transition-colors">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="gauge-line" />
      <div className="mx-auto max-w-6xl px-5 py-5 text-xs font-mono text-haze/70 flex flex-wrap gap-3 justify-between">
        <span>© {new Date().getFullYear()} VapeJuice.top — for verified-age adult readers only.</span>
        <span>Editorial content. Not medical advice. Not a retailer.</span>
      </div>
    </footer>
  );
}
