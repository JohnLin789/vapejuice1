import RatingGauge from "@/components/RatingGauge";

export default function ProductLabelCard({ product }) {
  const specs = [
    product.nicotineMg != null ? `${product.nicotineMg}MG` : null,
    product.bottleMl ? `${product.bottleMl}ML` : null,
    product.puffs ? `${product.puffs.toLocaleString()} PUFFS` : null,
    product.vgPg ? `${product.vgPg} VG/PG` : null
  ].filter(Boolean);

  return (
    <article className="label-card rounded-sm p-5 flex flex-col gap-4 h-full">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-display text-xs uppercase tracking-widest2 text-acid">
            {product.flavor}
          </p>
          <h3 className="font-display text-lg text-paper mt-1 leading-snug">
            {product.name}
          </h3>
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5 font-mono text-[11px] text-haze">
        {specs.map((s) => (
          <span key={s} className="border border-paper/15 rounded-sm px-2 py-1">
            {s}
          </span>
        ))}
      </div>

      <p className="text-sm font-body text-paper/85 leading-relaxed">{product.summary}</p>

      <div className="grid grid-cols-2 gap-4 text-xs font-body">
        <div>
          <p className="text-acid font-mono uppercase text-[10px] tracking-widest2 mb-1">Pros</p>
          <ul className="space-y-1 text-paper/75">
            {product.pros.map((p) => (
              <li key={p}>+ {p}</li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-ember font-mono uppercase text-[10px] tracking-widest2 mb-1">Cons</p>
          <ul className="space-y-1 text-paper/75">
            {product.cons.map((c) => (
              <li key={c}>− {c}</li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-auto pt-3 border-t border-paper/10">
        <RatingGauge rating={product.rating} size="compact" />
      </div>
    </article>
  );
}
