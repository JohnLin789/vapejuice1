/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}"
  ],
  theme: {
    extend: {
      colors: {
        ink: "#0B0E0C",
        panel: "#141914",
        paper: "#F5F2EA",
        haze: "#C9C2AE",
        acid: "#9FE870",
        ember: "#E2693A"
      },
      fontFamily: {
        display: ["var(--font-display)", "ui-sans-serif"],
        body: ["var(--font-body)", "ui-serif"],
        mono: ["var(--font-mono)", "ui-monospace"]
      },
      letterSpacing: {
        widest2: "0.22em"
      }
    }
  },
  plugins: []
};
